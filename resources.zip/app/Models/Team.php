<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    //
    protected $fillable = [
        'name',
        'designation',
        'image',
        'facebook',
        'instagram',
        'twitter',
        'portfolio',
        'number'
    ];
}
